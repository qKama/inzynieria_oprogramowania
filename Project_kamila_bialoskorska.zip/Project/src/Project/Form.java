package Project;

import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.reflect.Field;

public class Form extends JFrame {
    JTextField txt_name, txt_surname, txt_date, txt_mail, txt_phone;
    /*
    private DataBase database;
    static {
        String libraryPath = "C:\\Users\\qkama\\Downloads\\sqljdbc_12.6.2.0_enu\\sqljdbc_12.6\\enu\\auth\\x64";
        System.setProperty("java.library.path", libraryPath);

        try {
            Field sysPathsField = ClassLoader.class.getDeclaredField("sys_paths");
            sysPathsField.setAccessible(true);
            sysPathsField.set(null, null);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    } */
        
    public Form() {
        //database = new DataBase();
        setSize(1000, 820);
        setLayout(new BorderLayout());

        String voivodeship[] = {"Dolnośląskie", "Kujawsko-pomorskie", "Lubelskie", "Lubuskie", "Łódzkie", "Małopolskie", "Mazowieckie", "Opolskie", "Podkarpackie", "Podlaskie", "Pomorskie", "Śląskie", "Świętokrzyskie", "Warmińsko-mazurskie", "Wielkopolskie", "Zachodniopomorskie"};
        String positions[] = {"specjalista ds. obsługi klienta", "agent kredytowy", "doradca hipoteczny"};
        String city[] = {"Kraków", "Warszawa"};

        JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;

                Color bgColor = Color.WHITE;
                Color borderColor = new Color(0, 74, 173);

                // Example borders
                g2d.setColor(borderColor);
                g2d.fillRoundRect(40, 65, 220, 40, 20, 20);
                g2d.setColor(bgColor);
                g2d.fillRoundRect(42, 67, 216, 36, 20, 20);

                g2d.setColor(borderColor);
                g2d.fillRoundRect(40, 175, 220, 40, 20, 20);
                g2d.setColor(bgColor);
                g2d.fillRoundRect(42, 177, 216, 36, 20, 20);
            }
        };
        panel.setLayout(null);
        panel.setPreferredSize(new Dimension(900, 1000));

        JLabel Lb_name = new JLabel("Imię");
        Lb_name.setBounds(50, 20, 200, 30);
        panel.add(Lb_name);

        txt_name = new JTextField();
        txt_name.setBounds(50, 70, 200, 30);
        txt_name.setBorder(new LineBorder(Color.WHITE));
        panel.add(txt_name);

        JLabel Lb_surname = new JLabel("Nazwisko");
        Lb_surname.setBounds(50, 130, 200, 30);
        panel.add(Lb_surname);

        txt_surname = new JTextField();
        txt_surname.setBounds(50, 180, 200, 30);
        txt_surname.setBorder(new LineBorder(Color.WHITE));
        panel.add(txt_surname);

        JLabel Lb_date = new JLabel("Data Urodzenia");
        Lb_date.setBounds(50, 230, 200, 50);
        panel.add(Lb_date);

        txt_date = new JTextField();
        txt_date.setBounds(50, 260, 150, 30);
        panel.add(txt_date);

        JLabel Lb_mail = new JLabel("E-mail");
        Lb_mail.setBounds(50, 300, 200, 30);
        panel.add(Lb_mail);

        txt_mail = new JTextField();
        txt_mail.setBounds(50, 320, 150, 30);
        panel.add(txt_mail);

        JLabel Lb_phone = new JLabel("Nr. tel.");
        Lb_phone.setBounds(50, 370, 200, 30);
        panel.add(Lb_phone);

        txt_phone = new JTextField();
        txt_phone.setBounds(50, 390, 150, 30);
        panel.add(txt_phone);

        JLabel Lb_region = new JLabel("Wybierz region");
        Lb_region.setBounds(50, 440, 200, 30);
        JComboBox<String> cb_region = new JComboBox<>(voivodeship);
        cb_region.setBounds(50, 470, 200, 30);
        panel.add(cb_region);
        panel.add(Lb_region);

        JLabel Lb_city = new JLabel("Wybierz miasto");
        Lb_city.setBounds(50, 510, 200, 30);
        JComboBox<String> cb_city = new JComboBox<>(city);
        cb_city.setBounds(50, 540, 200, 30);
        panel.add(cb_city);
        panel.add(Lb_city);

        JLabel Lb_position = new JLabel("Wybierz na jaką stanowisko aplikujesz");
        Lb_position.setBounds(50, 580, 250, 30);
        JComboBox<String> cb_position = new JComboBox<>(positions);
        cb_position.setBounds(50, 610, 200, 30);
        panel.add(cb_position);
        panel.add(Lb_position);

        JLabel Lb_hour = new JLabel("Etat");
        Lb_hour.setBounds(50, 650, 200, 30);
        JCheckBox chbox_full = new JCheckBox("pełen etat");
        chbox_full.setBounds(50, 680, 200, 30);
        panel.add(chbox_full);
        panel.add(Lb_hour);

        JButton btn_save = new JButton("Zapisz");
        btn_save.setBounds(50, 740, 100, 30);
       /* btn_save.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String firstName = txt_name.getText();
                String lastName = txt_surname.getText();
                String birthDate = txt_date.getText();
                String email = txt_mail.getText();
                String phoneNumber = txt_phone.getText();
                String region = (String) cb_region.getSelectedItem();
                String city = (String) cb_city.getSelectedItem();
                String employmentType = (String) cb_position.getSelectedItem();
                String position = (String) cb_position.getSelectedItem();
                String contractType = "full-time"; // Example, adjust as needed
                String status = "active"; // Example, adjust as needed

                //database.saveDataToDatabase(firstName, lastName, birthDate, email, phoneNumber, region, city, employmentType, position, contractType, status);
            }
        }); */
        panel.add(btn_save);

        add(panel, BorderLayout.CENTER);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public static void main(String[] args) {
        new Form();
    }
}

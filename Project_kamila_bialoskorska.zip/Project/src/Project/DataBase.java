package Project;
/*
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DataBase {
    private Connection conn;

    static {
        // Load the native library explicitly
        System.load("C:\\Users\\qkama\\Downloads\\sqljdbc_12.6.2.0_enu\\sqljdbc_12.6\\enu\\auth\\x64\\mssql-jdbc_auth-12.6.2.x64.dll");
    }

    public DataBase() {
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String url = "jdbc:sqlserver://Kama\\SQLEXPRESS;databaseName=RecruitmentDB;integratedSecurity=true;encrypt=true;trustServerCertificate=true";
            conn = DriverManager.getConnection(url);
            System.out.println("Connected to the database.");
        } catch (ClassNotFoundException e) {
            System.out.println("SQL Server JDBC driver not found.");
            e.printStackTrace();
        } catch (SQLException e) {
            System.out.println("Failed to connect to the database.");
            e.printStackTrace();
        }
    }

    public void saveDataToDatabase(String firstName, String lastName, String birthDate, String email, String phoneNumber, String region, String city, String employmentType, String position, String contractType, String status) {
        try {
            Statement stmt = conn.createStatement();
            String query = String.format(
                "INSERT INTO Candidates (firstName, lastName, birthDate, email, phoneNumber, region, city, employmentType, position, contractType, status) " +
                "VALUES ('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')",
                firstName, lastName, birthDate, email, phoneNumber, region, city, employmentType, position, contractType, status
            );
            stmt.executeUpdate(query);
            System.out.println("Data saved to database.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void fetchData() {
        try {
            if (conn != null) {
                Statement stmt = conn.createStatement();
                String query = "SELECT * FROM Candidates";
                ResultSet rs = stmt.executeQuery(query);
                while (rs.next()) {
                    System.out.println("First Name: " + rs.getString("firstName"));
                    System.out.println("Last Name: " + rs.getString("lastName"));
                    System.out.println("Birth Date: " + rs.getString("birthDate"));
                    System.out.println("Email: " + rs.getString("email"));
                    System.out.println("Phone Number: " + rs.getString("phoneNumber"));
                    System.out.println("Region: " + rs.getString("region"));
                    System.out.println("City: " + rs.getString("city"));
                    System.out.println("Employment Type: " + rs.getString("employmentType"));
                    System.out.println("Position: " + rs.getString("position"));
                    System.out.println("Contract Type: " + rs.getString("contractType"));
                    System.out.println("Status: " + rs.getString("status"));
                }
            } else {
                System.out.println("No connection to the database.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        DataBase db = new DataBase();
        db.fetchData();
    }
}
*/
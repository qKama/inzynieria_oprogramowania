package Project;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;

import javax.swing.*;  


public class MainPage extends JFrame{
	JFrame f;  
	MainPage(){  
	
		setSize(900,820); 
		setLayout(new BorderLayout()); 
		
		GradientPanel gradientPanel = new GradientPanel();	
		add(gradientPanel, BorderLayout.CENTER);
        
		setVisible(true);  
	}  
	public static void main(String[] args) {  
		new MainPage();  
	}
	class GradientPanel extends JPanel {
	    @Override
	    protected void paintComponent(Graphics g) {
	        super.paintComponent(g);
	        Graphics2D g2d = (Graphics2D) g;
	        Color color1 = Color.WHITE;
	        Color color2 = new Color(244, 211, 137);
	        
	        int width = getWidth();
	        int height = getHeight();
	        
	        GradientPaint gradientPaint = new GradientPaint(0, 0, color1, 0, height, color2);
	        g2d.setPaint(gradientPaint);
	        g2d.fillRect(0, 0, width, height);
	        

	        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

	        //menu bar
	        g2d.setColor(new Color(255, 164, 84));
	        g2d.fillRoundRect(0, 0, getWidth(), 50, 20, 20);
	        
            g2d.setColor(new Color(9, 155, 216, 40)); 
            g2d.fillOval(-70, 550, 400, 400);
	   
	}
	}
}  